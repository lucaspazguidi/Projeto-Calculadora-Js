let nome = "Thiago Silva"
newName = nome.split(" ")
console.log(newName);
console.log(`Seu nome é ${newName[0].toLocaleUpperCase()}, ja seu sobrenome é ${newName[1].toLocaleUpperCase()}, correto?`)
console.log(nome.substring(0,6));