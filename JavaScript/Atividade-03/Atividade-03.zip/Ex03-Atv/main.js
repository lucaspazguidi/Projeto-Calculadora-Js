let nota = 59
if (nota >= 90 && nota <= 100){
    console.log(`Parabens! Com a sua nota ${nota}, voce tirou A!`);
}
if (nota >= 80 && nota < 90){
    console.log(`Parabens! Com a sua nota ${nota}, voce tirou B!`);
}
if (nota >= 70 && nota < 80){
    console.log(`Parabens! Com a sua nota ${nota}, voce tirou C!`);
}
if (nota >= 60 && nota <70){
    console.log(`Parabens! Com a sua nota ${nota}, voce tirou D!`);
}
if (nota < 60){
    console.log(`Com a sua nota ${nota}, voce tirou F!`);
}
else{
    console.log("");
}